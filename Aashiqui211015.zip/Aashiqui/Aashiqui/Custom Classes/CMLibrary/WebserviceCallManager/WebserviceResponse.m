//
//  WebserviceResponse.m
//  VideoTag
//
//  Created by Aditya Aggarwal on 24/04/14.
//
//

#import "WebserviceResponse.h"

@implementation WebserviceResponse

- (void)dealloc
{
    _webserviceUrl = nil;
    _webserviceResponse = nil;
}

@end
