#import <UIKit/UIKit.h>
#import "HFImageEditorViewController.h"

@interface HFImageEditorFrameView : UIView<HFImageEditorFrame>

@end
