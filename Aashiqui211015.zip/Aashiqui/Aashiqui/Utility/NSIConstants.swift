//
//  NSIConstants.swift
//  Aashiqui
//
//  Created by ketan saini on 12/10/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class NSIConstants: NSObject {
    
    static let usernameCheck: String = "Please enter Username."
    static let passwordCheck: String = "Please enter Password."
    static let underConstruction: String = "Under Construction."
    static let emailCheck: String = "Please enter Email."
    static let statusUpdateCheck: String = "Status Updated Successfully."
    
    static let userDefaults = NSUserDefaults.standardUserDefaults()
    static let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
    static let ObjMainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
}
