//
//  Utility.swift
//  Aashiqui
//
//  Created by ketan saini on 14/09/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit
import Foundation
import SystemConfiguration

class Utility: NSObject {
    
    // MARK: - NavigationBar TitleView Label
    class func navBarTitleLabel(title:String) -> UILabel{
        let labelTitle = UILabel(frame: CGRectMake(0, 0, 200, 25))
        labelTitle.textAlignment = NSTextAlignment.Center
        labelTitle.font = UIFont(name: "Lato-Bold", size: 18.0)
        labelTitle.textColor = UIColor.whiteColor()
        labelTitle.text = title
        return labelTitle
    }
    
    // MARK: - NavigationBar LeftBarButtonItem
    class func navBarLeftButton(image:UIImage, viewController:UIViewController) ->UIBarButtonItem{
        let leftButton   = UIButton(type: UIButtonType.Custom)
        leftButton.frame = CGRectMake(0, 0, 30, 30)
        leftButton.backgroundColor = UIColor.clearColor()
        leftButton.setTitle("", forState: UIControlState.Normal)
        leftButton.setImage(image, forState: UIControlState.Normal)
        leftButton.addTarget(viewController, action: "fnLeftBarButton", forControlEvents: UIControlEvents.TouchUpInside)
        let barButtonItem:UIBarButtonItem = UIBarButtonItem()
        barButtonItem.customView = leftButton
        return barButtonItem
    }
    
    
    // MARK: - NavigationBar RightBarButtonItem
    class func navBarRightButton(image:UIImage, viewController:UIViewController) ->UIBarButtonItem{
        let rightButton   = UIButton(type: UIButtonType.Custom)
        rightButton.frame = CGRectMake(0, 0, 30, 30)
        rightButton.backgroundColor = UIColor.clearColor()
        rightButton.setTitle("", forState: UIControlState.Normal)
        rightButton.setImage(image, forState: UIControlState.Normal)
        rightButton.addTarget(viewController, action: "fnRightBarButton", forControlEvents: UIControlEvents.TouchUpInside)
        let barButtonItem:UIBarButtonItem = UIBarButtonItem()
        barButtonItem.customView = rightButton
        return barButtonItem
        
    }
    
    // MARK: - Check For Empty String
    class func checkIfStringContainsText(string:String?) -> Bool
    {
        if let stringEmpty = string {
            let newString = stringEmpty.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
            if(newString.isEmpty){
                return false
            }
            return true
        } else {
            return false
        }
    }
    
    // MARK: - Check Email validation
    class func validateEmail(emailStr:String) -> Bool
    {
        let emailRegex:String = "^[_\\p{L}\\p{Mark}0-9-]+(\\.[_\\p{L}\\p{Mark}0-9-]+)*@[\\p{L}\\p{Mark}0-9-]+(\\.[\\p{L}\\p{Mark}0-9]+)*(\\.[\\p{L}\\p{Mark}]{2,})$"
        let predicateForEmail:NSPredicate = NSPredicate(format: "SELF MATCHES %@",emailRegex)
        return predicateForEmail.evaluateWithObject(emailStr);
    }
    
    // MARK: - Show AlertView Methods
    class func showAlert(title:String, message:String, delegate:AnyObject?) {
        let alertView = UIAlertView(title: title, message: message, delegate: delegate, cancelButtonTitle: "OK")
        alertView.show()
    }
        
    
    class func getCurrentTime() -> String{
        let date = NSDate();
        // "Jul 23, 2014, 11:01 AM" <-- looks local without seconds. But:
        
        let formatter = NSDateFormatter();
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss ZZZ";
        let defaultTimeZoneStr = formatter.stringFromDate(date);
        // "2014-07-23 11:01:35 -0700" <-- same date, local, but with seconds
        print("localTime", "\(defaultTimeZoneStr)")
        
        formatter.timeZone = NSTimeZone(abbreviation: "UTC");
        let utcTimeZoneStr = formatter.stringFromDate(date);
        // "2014-07-23 18:01:41 +0000" <-- same date, now in UTC
        print("utcTime", "\(utcTimeZoneStr)")
        return utcTimeZoneStr
    }
    
    class func RBResizeImage(image: UIImage, targetSize: CGSize) -> UIImage {
        let size = image.size
        
        let widthRatio  = targetSize.width  / image.size.width
        let heightRatio = targetSize.height / image.size.height
        
        // Figure out what our orientation is, and use that to form the rectangle
        var newSize: CGSize
        if(widthRatio > heightRatio) {
            newSize = CGSizeMake(size.width * heightRatio, size.height * heightRatio)
        } else {
            newSize = CGSizeMake(size.width * widthRatio,  size.height * widthRatio)
        }
        
        // This is the rect that we've calculated out and this is what is actually used below
        let rect = CGRectMake(0, 0, newSize.width, newSize.height)
        
        // Actually do the resizing to the rect using the ImageContext stuff
        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        image.drawInRect(rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage
    }
    
    class func isValidUsername(testStr:String) -> Bool {
        let emailRegEx = "[a-zA-Z0-9._]*"
        let strUsername = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return strUsername.evaluateWithObject(testStr)
    }
    
}
