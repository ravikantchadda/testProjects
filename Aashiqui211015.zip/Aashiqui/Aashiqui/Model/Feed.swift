//
//  Feed.swift
//  Aashiqui
//
//  Created by ketan saini on 14/10/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class Feed: NSObject {
    //MARK: class variables
    /*
    audioUrl = "";
    commentsCount = 0;
    firstName = Thomas;
    isBookmark = 0;
    lastName = Ben;
    location = "Panchkula ,Rajiv Gandhi Chandigarh Technology Park Road";
    minutesAgo = 1484;
    photo = "http://gsu-miscwork02.netsolutions.in/images/2763/status/a599fdd73c746e82e17dc58fbcfdbda2.png";
    postId = 43855;
    postTimeStamp = "2015-10-13 04:25:51";
    profilePic = "http://gsu-miscwork02.netsolutions.in/images/2763/profilepic/57ecfe6e076000dca04a4a2baf16c7dc.png";
    statusText = Thomas;
    taggedFriendList =         (
    );
    userId = 2763;
    viewsCount = 0;
    */
    var audioUrl:String!
    var commentsCount:String!
    var firstName:String!
    var lastName:String!
    var location:String!
    var minutesAgo:String!
    var photo:String!
    var postId:String!
    var profilePic:String!
    var statusText:String!
    var userId:String!
    var viewsCount:String!
    var taggedFriendList: NSMutableArray!
    
    // MARK: NSCoding
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.audioUrl = (decoder.decodeObjectForKey("audioUrl") as! String?)!
        self.commentsCount = (decoder.decodeObjectForKey("commentsCount") as! String?)!
        self.firstName = (decoder.decodeObjectForKey("firstName") as! String?)!
        self.lastName = (decoder.decodeObjectForKey("lastName") as! String?)!
        self.location = (decoder.decodeObjectForKey("location") as! String?)!
        self.minutesAgo = (decoder.decodeObjectForKey("minutesAgo") as! String?)!
        self.photo = (decoder.decodeObjectForKey("photo") as! String?)!
        self.postId = (decoder.decodeObjectForKey("postId") as! String?)!
        self.profilePic = (decoder.decodeObjectForKey("profilePic") as! String?)!
        self.statusText = (decoder.decodeObjectForKey("statusText") as! String?)!
        self.userId = (decoder.decodeObjectForKey("userId") as! String?)!
        self.viewsCount = (decoder.decodeObjectForKey("viewsCount") as! String?)!
        self.taggedFriendList = (decoder.decodeObjectForKey("taggedFriendList") as! NSMutableArray?)!
    }
    
    func encodeWithCoder(coder: NSCoder) {
        coder.encodeObject(self.audioUrl, forKey: "audioUrl")
        coder.encodeObject(self.commentsCount, forKey: "commentsCount")
        coder.encodeObject(self.firstName, forKey: "firstName")
        coder.encodeObject(self.lastName, forKey: "lastName")
        coder.encodeObject(self.location, forKey: "location")
        coder.encodeObject(self.minutesAgo, forKey: "minutesAgo")
        coder.encodeObject(self.photo, forKey: "photo")
        coder.encodeObject(self.postId, forKey: "postId")
        coder.encodeObject(self.profilePic, forKey: "profilePic")
        coder.encodeObject(self.statusText, forKey: "statusText")
        coder.encodeObject(self.userId, forKey: "userId")
        coder.encodeObject(self.viewsCount, forKey: "viewsCount")
        coder.encodeObject(self.taggedFriendList, forKey: "taggedFriendList")
    }
    
    
    func fillDataInModel(arrData: NSArray) -> NSMutableArray {
        let arrFeedData: NSMutableArray! = []
        for dict in arrData{
            let objFeed = Feed()
            objFeed.audioUrl = dict.valueForKey("audioUrl") as! String
            objFeed.commentsCount = dict.valueForKey("commentsCount") as! String
            objFeed.firstName = dict.valueForKey("firstName") as! String
            objFeed.lastName = dict.valueForKey("lastName") as! String
            objFeed.location = dict.valueForKey("location") as! String
            objFeed.minutesAgo = dict.valueForKey("minutesAgo") as! String
            objFeed.photo = dict.valueForKey("photo") as! String
            objFeed.postId = dict.valueForKey("postId") as! String
            objFeed.statusText = dict.valueForKey("statusText") as! String
            objFeed.userId = dict.valueForKey("userId") as! String
            objFeed.viewsCount = dict.valueForKey("viewsCount")?.stringValue
            if (dict.valueForKey("profilePic")?.isKindOfClass(NSNull) != true){
                objFeed.profilePic = dict.valueForKey("profilePic") as! String
            }else{
                objFeed.profilePic = ""
            }
            
            let arrTaggedFriends: NSMutableArray = []
            for dict in dict.valueForKey("taggedFriendList") as! NSArray{
                let objTaggedFriends = TagFriendList()
                objTaggedFriends.nickName = dict.valueForKey("nickName") as! String
                //                    objTaggedFriends.profilePic = dict.valueForKey("profilePic") as! String
                objTaggedFriends.userId = dict.valueForKey("userId") as! String
                if (dict.valueForKey("profilePic")?.isKindOfClass(NSNull) != true){
                    objTaggedFriends.profilePic = dict.valueForKey("profilePic") as! String
                }else{
                    objTaggedFriends.profilePic = ""
                }
                arrTaggedFriends.addObject(objTaggedFriends)
            }
            objFeed.taggedFriendList = arrTaggedFriends
            arrFeedData.addObject(objFeed)
        }
        return arrFeedData
    }
}

class TagFriendList: NSObject{
    /*
    taggedFriendList =         (
    {
    nickName = "Aanchal Jain";
    profilePic = "http://gsu-miscwork02-qa.netsol.in/images/498/profilepic/IMAGE_23-06-2015-11_37_39.PNG";
    userId = 498;
    }
    );
    */
    var nickName:String!
    var profilePic:String!
    var userId:String!
    
    // MARK: NSCoding
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.nickName = (decoder.decodeObjectForKey("nickName") as! String?)!
        self.profilePic = (decoder.decodeObjectForKey("profilePic") as! String?)!
        self.userId = (decoder.decodeObjectForKey("userId") as! String?)!
        
    }
    
    func encodeWithCoder(coder: NSCoder) {
        coder.encodeObject(self.nickName, forKey: "nickName")
        coder.encodeObject(self.profilePic, forKey: "profilePic")
        coder.encodeObject(self.userId, forKey: "userId")
        
    }

}
