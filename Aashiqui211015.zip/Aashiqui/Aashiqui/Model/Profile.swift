//
//  Profile.swift
//  Aashiqui
//
//  Created by ketan saini on 20/10/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class Profile: NSObject {
    /*
    aboutMe = "";
    count =         {
    friendsCount = 0;
    postCount = 55;
    profileGotLikedCount = 0;
    uploadedPhotosCount = 0;
    };
    firstName = Ketan;
    friends =         (
    );
    isProfileActive = 1;
    lastName = Saini;
    
    profileId = 2798;
    profilePic = "";
*/
    var aboutMe:String!
    var firstName:String!
    var lastName:String!
    var friendsCount:String!
    var postCount:String!
    var profileGotLikedCount:String!
    var uploadedPhotosCount:String!
    var profilePic:String!
    var profileId:String!
    
    let aboutMeKey = "aboutMe"
    let firstNameKey = "firstName"
    let lastNameKey = "lastName"
    let friendsCountKey = "friendsCount"
    let postCountKey = "postCount"
    let profileGotLikedCountKey = "profileGotLikedCount"
    let uploadedPhotosCountKey = "uploadedPhotosCount"
    let profilePicKey = "profilePic"
    let profileIdKey = "profileId"
    
    // MARK: NSCoding
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.aboutMe = (decoder.decodeObjectForKey(aboutMeKey) as! String?)!
        self.firstName = (decoder.decodeObjectForKey(firstNameKey) as! String?)!
        self.lastName = (decoder.decodeObjectForKey(lastNameKey) as! String?)!
        self.friendsCount = (decoder.decodeObjectForKey(friendsCountKey) as! String?)!
        self.postCount = (decoder.decodeObjectForKey(postCountKey) as! String?)!
        self.profileGotLikedCount = (decoder.decodeObjectForKey(profileGotLikedCountKey) as! String?)!
        self.uploadedPhotosCount = (decoder.decodeObjectForKey(uploadedPhotosCountKey) as! String?)!
        self.profilePic = (decoder.decodeObjectForKey(profilePicKey) as! String?)!
        self.profileId = (decoder.decodeObjectForKey(profileIdKey) as! String?)!

        
    }
    
    func encodeWithCoder(coder: NSCoder) {
        coder.encodeObject(self.aboutMe, forKey: aboutMeKey)
        coder.encodeObject(self.firstName, forKey: firstNameKey)
        coder.encodeObject(self.lastName, forKey: lastNameKey)
        coder.encodeObject(self.friendsCount, forKey: friendsCountKey)
        coder.encodeObject(self.postCount, forKey: postCountKey)
        coder.encodeObject(self.profileGotLikedCount, forKey: profileGotLikedCountKey)
        coder.encodeObject(self.uploadedPhotosCount, forKey: uploadedPhotosCountKey)
        coder.encodeObject(self.profilePic, forKey: profilePicKey)
        coder.encodeObject(self.profileId, forKey: profileIdKey)
        
    }
    
    func fillProfileDataInModel(dictData: NSDictionary) -> Profile {
        let objProfile = Profile()
        
        if (dictData.valueForKey(aboutMeKey)?.isKindOfClass(NSNull) != true){
            objProfile.aboutMe = dictData.valueForKey(aboutMeKey) as! String
        }else{
            objProfile.aboutMe = ""
        }
        objProfile.firstName = dictData.valueForKey(firstNameKey) as! String
        objProfile.lastName = dictData.valueForKey(lastNameKey) as! String
        objProfile.friendsCount = dictData.valueForKey("count")!.valueForKey(friendsCountKey) as! String
        objProfile.postCount = dictData.valueForKey("count")!.valueForKey(postCountKey) as! String
        objProfile.profileGotLikedCount = dictData.valueForKey("count")!.valueForKey(profileGotLikedCountKey) as! String
        objProfile.uploadedPhotosCount = dictData.valueForKey("count")!.valueForKey(uploadedPhotosCountKey) as! String
        if (dictData.valueForKey(profilePicKey)?.isKindOfClass(NSNull) != true){
            objProfile.profilePic = dictData.valueForKey(profilePicKey) as! String
        }else{
            objProfile.profilePic = ""
        }
        objProfile.profileId = dictData.valueForKey(profileIdKey) as! String
        
        return objProfile
    }

}
