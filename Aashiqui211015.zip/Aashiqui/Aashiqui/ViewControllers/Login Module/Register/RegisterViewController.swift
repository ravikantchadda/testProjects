//
//  RegisterViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 18/09/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit

class RegisterViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIActionSheetDelegate {
    
    @IBOutlet weak var scrollVw_Container: UIScrollView!
    @IBOutlet weak var btnTakePicture: UIButton!
    @IBOutlet weak var txtFirstName: UITextField!
    @IBOutlet weak var txtLastName: UITextField!
    @IBOutlet weak var txtUsername: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPhoneNo: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtConfirmPassword: UITextField!
    @IBOutlet weak var vwContainerObj: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.navigationController?.navigationBarHidden = false
        self.navigationItem.leftBarButtonItem = Utility.navBarLeftButton(UIImage(named: "btnBack")!, viewController: self)
        self.navigationItem.titleView = Utility.navBarTitleLabel("Sign Up")
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillLayoutSubviews() {
        
        scrollVw_Container.contentSize = CGSizeMake(290, 550)
    }
    
    // MARK: - NavigationBar LeftBarButton Method
    func fnLeftBarButton(){
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    // MARK: - UITextField Delegate Method
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        let nextTag:NSInteger = textField.tag + 1
        // Try to find next responder
        let nextResponder = textField.superview?.viewWithTag(nextTag)
        if (nextResponder != nil){
            nextResponder!.becomeFirstResponder()
        }else{
            textField.resignFirstResponder()
        }
        return true
    }
    
    // MARK: - UIButton Action
    @IBAction func btnTapped_SignUp(sender: AnyObject) {
        self.view.endEditing(true)
        let strError = fnCheckValidation()
        if strError == ""{
            let dict:NSDictionary = [
                "userName": txtUsername.text!,
                "firstName": txtFirstName.text!,
                "lastName": txtLastName.text!,
                "phone": txtPhoneNo.text!,
                "password": txtPassword.text!,
                "email": txtEmail.text!
            ]
            print("\(dict)")
            fnSignUpWebServiceWithPostDic(dict)
            
        }else{
            Utility.showAlert("", message: strError as String, delegate: nil)
        }
        
    }
    @IBAction func btnPressed_termsCondition(sender: AnyObject) {
        let objTerms: TermsViewController = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("TermsViewController") as! TermsViewController
        self.navigationController!.pushViewController(objTerms, animated: true)
    }
    
    @IBAction func btnTapped_TakePic(sender: AnyObject) {
        self.view.endEditing(true)
        if #available(iOS 8.0, *) {
            let objOptionMenu = UIAlertController(title: nil, message: "Choose Option", preferredStyle: .ActionSheet)
            let cameraAction = UIAlertAction(title: "Camera", style: .Default, handler: {
                (alert: UIAlertAction) -> Void in
                self.fnOpenCamera()
            })
            
            let galleryAction = UIAlertAction(title: "Gallery", style: .Default, handler: {
                (alert: UIAlertAction) -> Void in
                self.fnOpenPhotoGallery()
            })
            
            let cancelAction = UIAlertAction(title: "Cancel", style: .Cancel, handler: {
                (alert: UIAlertAction) -> Void in
                
            })
            
            objOptionMenu.addAction(cameraAction)
            objOptionMenu.addAction(galleryAction)
            objOptionMenu.addAction(cancelAction)
            
            self.presentViewController(objOptionMenu, animated: true, completion: nil)
        } else {
            // Fallback on earlier versions
            let objActionSheet = UIActionSheet()
            objActionSheet.title = "Choose Option"
            objActionSheet.addButtonWithTitle("Camera")
            objActionSheet.addButtonWithTitle("Gallery")
            objActionSheet.addButtonWithTitle("Cancel")
            objActionSheet.cancelButtonIndex = 2
            objActionSheet.tag = 2356
            objActionSheet.delegate = self
            objActionSheet.showInView(self.view)
        }
         
    }
    
    @IBAction func btnPressed_FacebookLogin(sender: AnyObject) {
        self.view.endEditing(true)
        let fbLogin = FBSDKLoginManager()
        fbLogin .logInWithReadPermissions(["email"], handler: { (result, error) -> Void in
            if (error == nil){
                let fbloginresult : FBSDKLoginManagerLoginResult = result
                if fbloginresult.isCancelled {
                    // Handle cancellations
                    print("isCancelled\(result.isCancelled)")
                    
                }else if(fbloginresult.grantedPermissions.contains("email"))
                {
                    self.getFBUserData()
                }
            }
        })
    }
    
    func getFBUserData(){
        if((FBSDKAccessToken.currentAccessToken()) != nil){
            FBSDKGraphRequest(graphPath: "me", parameters: ["fields": "id, name, first_name, last_name, picture.type(large), email"]).startWithCompletionHandler({ (connection, result, error) -> Void in
                if (error == nil){
                    print(result)
                    let dict:NSDictionary = [
                        "firstName": result.valueForKey("first_name")!,
                        "lastName": result.valueForKey("last_name")!,
                        "phone": "",
                        "fbId": result.valueForKey("id")!,
                        "email": result.valueForKey("email")!,
                        "profilePic": result.valueForKey("picture")!.valueForKey("data")!.valueForKey("url")!
                    ]
                    print("\(dict)")
                    self.fnFBSignInWebServiceWithPostDic(dict)
                }
            })
        }
    }
    
    func actionSheet(myActionSheet: UIActionSheet, clickedButtonAtIndex buttonIndex: Int){
        if(myActionSheet.tag == 2356){
            
            if (buttonIndex == 0){
                print("the index is 0")
                self.fnOpenCamera()
            }
            if (buttonIndex == 1){
                print("the index is 1")
                self.fnOpenPhotoGallery()
            }
            if (buttonIndex == 2){
                print("the index is 2")
            }
            
        }
    }
    func fnOpenCamera() {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera)
        {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.allowsEditing = true
            imagePicker.sourceType = UIImagePickerControllerSourceType.Camera;
            self.presentViewController(imagePicker, animated: true, completion: nil)
            
        }else{
            Utility.showAlert("", message: "Camera not available." as String, delegate: nil)
        }
    }
    
    func fnOpenPhotoGallery() {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.PhotoLibrary){
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.allowsEditing = true
            imagePicker.sourceType = UIImagePickerControllerSourceType.PhotoLibrary;
            self.presentViewController(imagePicker, animated: true, completion: nil)
            
        }else{
            Utility.showAlert("", message: "Gallery not available." as String, delegate: nil)
        }
    }
    
    
    // MARK: - UIImagePickerControllerDelegate Methods
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        if let pickedImage = info[UIImagePickerControllerEditedImage] as? UIImage {
            btnTakePicture .setBackgroundImage(Utility.RBResizeImage(pickedImage, targetSize: CGSizeMake(640, 640)), forState: UIControlState.Normal)
        }
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    // MARK: - Webservice Call Methods
    // SignUp API
    func fnSignUpWebServiceWithPostDic(dict: NSDictionary!) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        //        ObjWebserviceCall.cachePolicy = WebserviceCallCachePolicyRequestFromCacheFirstAndThenFromUrlAndUpdateInCache
        ObjWebserviceCall.isShowLoader = true
        if let DToken = NSIConstants.userDefaults.valueForKey("DEVICETOKEN") {
            
            ObjWebserviceCall.headerFieldsDict = ["DEVICETOKEN":DToken]
            
        }else{
            ObjWebserviceCall.headerFieldsDict = ["DEVICETOKEN":"y6734y78rt334y734y785yt3897ty3893t35"]
        }
        var imgData: NSData? = nil
        ObjWebserviceCall.parametersDict = dict! as [NSObject : AnyObject]
        if((btnTakePicture.backgroundImageForState(.Normal)) != nil){
            imgData = UIImagePNGRepresentation((btnTakePicture.backgroundImageForState(.Normal))!)!
        }
        ObjWebserviceCall.uploadDataWithImage(imgData, withFileType: "profilePic", onUrl: NSURL(string: "\(BASE_URL+WebserviceSignUp)"), withSuccessHandler: { (response: WebserviceResponse!) -> Void in
            let response = response
            print("\(response.webserviceResponse)")
            
            if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                let objLogin = Login()
                objLogin.userUserName = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("nickName") as! String
                objLogin.userEmail = "ex@ex.com"
                objLogin.userId = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("userId") as! String
                objLogin.userDeviceId = "ewew2323ewew"
                objLogin.userAuthToken = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("authToken") as! String
                objLogin.userPost = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("feeds") as! NSArray
                
                let objTabBarViewController = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("TabBarViewController") as! TabBarViewController
                let objNavigationHome = objTabBarViewController.viewControllers![0] as! UINavigationController
                let objHome: HomeViewController = objNavigationHome.viewControllers.first as! HomeViewController
                objHome.objLoginModel = objLogin
                self.navigationController!.pushViewController(objTabBarViewController, animated: false)
            }else{
                Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
            }
            
            
            })
            { (error: NSError!) -> Void in
                let error = error
                print("\(error)")
        }
    }
    
    // Facebook Login API
    func fnFBSignInWebServiceWithPostDic(dict: NSDictionary!) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        //        ObjWebserviceCall.cachePolicy = WebserviceCallCachePolicyRequestFromCacheFirstAndThenFromUrlAndUpdateInCache
        ObjWebserviceCall.isShowLoader = true
        if let DToken = NSIConstants.userDefaults.valueForKey("DEVICETOKEN") {
            ObjWebserviceCall.headerFieldsDict = ["DEVICETOKEN":DToken]
        }else{
            ObjWebserviceCall.headerFieldsDict = ["DEVICETOKEN":"y6734y78rt334y734y785yt3897ty3893t35"]
        }
        ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceFBlogin)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
            let response = response
            print("\(response.webserviceResponse)")
            
            if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                let objLogin = Login()
                objLogin.userUserName = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("nickName") as! String
                objLogin.userEmail = "ex@ex.com"
                objLogin.userId = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("userId") as! String
                objLogin.userDeviceId = "ewew2323ewew"
                objLogin.userAuthToken = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("authToken") as! String
                objLogin.userPost = response.webserviceResponse.valueForKey("userDetail")?.valueForKey("feeds") as! NSArray
                
                let objTabBarViewController = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("TabBarViewController") as! TabBarViewController
                let objNavigationHome = objTabBarViewController.viewControllers![0] as! UINavigationController
                let objHome: HomeViewController = objNavigationHome.viewControllers.first as! HomeViewController
                objHome.objLoginModel = objLogin
                self.navigationController!.pushViewController(objTabBarViewController, animated: false)
            }else{
                self.txtUsername.text = ""
                self.txtPassword.text = ""
                Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
            }
            
            }) { (error: NSError!) -> Void in
        }
    }
    
    // MARK: - Validations check
    func fnCheckValidation() -> NSString{
        var strError = String()
        
        if !Utility.checkIfStringContainsText(txtFirstName.text){
            strError = "Please enter First name."
        }else if !Utility.checkIfStringContainsText(txtLastName.text){
            strError = "Please enter Last name."
        }else if !Utility.checkIfStringContainsText(txtUsername.text){
            strError = NSIConstants.usernameCheck
        }else if !Utility.isValidUsername(txtUsername.text!){
            strError = "Invalid Username(a-z, A-Z, 0-9, _ , . only)"
        }else if !Utility.checkIfStringContainsText(txtEmail.text){
            strError = "Please enter Email address."
        }else if !Utility.validateEmail(txtEmail.text!){
            strError = "Please enter valid Email address."
        }else if !Utility.checkIfStringContainsText(txtPhoneNo.text){
            strError = "Please enter Phone number."
        }else if (!Utility.checkIfStringContainsText(txtPassword.text)){
            strError = NSIConstants.passwordCheck
        }else if txtPassword.text!.characters.count < 6{
            strError = "Password must contain 6 or more characters."
        }else if (!Utility.checkIfStringContainsText(txtConfirmPassword.text)){
            strError = "Please enter Confirm Password."
        }else if txtPassword.text != txtConfirmPassword.text{
            strError = "Confirm Password does not match Password."
        }
        
        return strError
    }
    
    @IBAction func textEnterBegin(sender: AnyObject) {
        if (sender.tag == 104){
            self.checkMaxLength(sender as! UITextField, maxLength: 15)
        }else if(sender.tag == 103){
            self.checkMaxLength(sender as! UITextField, maxLength: 50)
        }else{
            self.checkMaxLength(sender as! UITextField, maxLength: 30)
        }
        
    }
    
    func checkMaxLength(textField: UITextField!, maxLength: Int) {
        let str = textField.text
        let strCount = str!.characters.count
        if (strCount > maxLength) {
            textField.deleteBackward()
        }
    }
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    
    
    
}
