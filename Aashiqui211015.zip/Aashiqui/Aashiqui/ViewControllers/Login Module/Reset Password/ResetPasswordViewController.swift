//
//  ResetPasswordViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 18/09/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit

class ResetPasswordViewController: UIViewController {
    @IBOutlet weak var txtEmail: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        UIApplication.sharedApplication().statusBarStyle = .Default
    }
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        UIApplication.sharedApplication().statusBarStyle = .LightContent
    }
    
    @IBAction func btnPressed_Cross(sender: AnyObject) {
        self .dismissViewControllerAnimated(true, completion: nil)
    }
    @IBAction func btnPressed_ResetPassword(sender: AnyObject) {
        self.view.endEditing(true)
        if !Utility.checkIfStringContainsText(txtEmail.text){
            Utility.showAlert("", message: NSIConstants.emailCheck, delegate: nil)
        }else{
            Utility.showAlert("", message: NSIConstants.underConstruction, delegate: nil)
        }
    }
    
    // MARK: - UITextField Delegate Method
    func textFieldShouldReturn(textField: UITextField) -> Bool{
        textField .resignFirstResponder()
        return true
    }
    
    // MARK: - Validations check
    func fnCheckValidation() -> NSString{
        var strError = String()
        if !Utility.checkIfStringContainsText(txtEmail.text){
            strError = NSIConstants.emailCheck
        }else if !Utility.validateEmail(txtEmail.text!){
            strError = "Please enter valid Email."
        }
        return strError
    }
    
    @IBAction func textEnterBegin(sender: AnyObject) {
        self.checkMaxLength(sender as! UITextField, maxLength: 30)
    }
    func checkMaxLength(textField: UITextField!, maxLength: Int) {
        let str = textField.text
        let strCount = str!.characters.count
        if (strCount > maxLength) {
            textField.deleteBackward()
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
