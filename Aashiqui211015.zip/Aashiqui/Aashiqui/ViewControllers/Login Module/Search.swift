//
//  Search.swift
//  Aashiqui
//
//  Created by ketan saini on 16/10/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class Search: NSObject {
    /*
    {
    "userId": "2765",
    "firstName": "Nitin",
    "lastName": "Saluja",
    "nickName": "",
    "profilePic": "",
    "usStatusText": “”
    }

    */
    
    var userId:String!
    var firstName:String!
    var lastName:String!
    var statusText:String!
    var profilePic:String!
    
    // MARK: NSCoding
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.userId = (decoder.decodeObjectForKey("userId") as! String?)!
        self.firstName = (decoder.decodeObjectForKey("firstName") as! String?)!
        self.lastName = (decoder.decodeObjectForKey("lastName") as! String?)!
        self.statusText = (decoder.decodeObjectForKey("statusText") as! String?)!
        self.profilePic = (decoder.decodeObjectForKey("profilePic") as! String?)!
        
    }
    
    func encodeWithCoder(coder: NSCoder) {
        coder.encodeObject(self.userId, forKey: "userId")
        coder.encodeObject(self.firstName, forKey: "firstName")
        coder.encodeObject(self.lastName, forKey: "lastName")
        coder.encodeObject(self.statusText, forKey: "statusText")
        coder.encodeObject(self.profilePic, forKey: "profilePic")
        
    }
    
    func fillDataInModel(arrData: NSArray) -> NSMutableArray {
        let arrUserData: NSMutableArray! = []
        for dict in arrData{
            let objUser = Search()
            objUser.userId = dict.valueForKey("userId") as! String
            objUser.firstName = dict.valueForKey("firstName") as! String
            objUser.lastName = dict.valueForKey("lastName") as! String
            objUser.statusText = dict.valueForKey("statusText") as! String
            if (dict.valueForKey("profilePic")?.isKindOfClass(NSNull) != true){
                objUser.profilePic = dict.valueForKey("profilePic") as! String
            }else{
                objUser.profilePic = ""
            }
            if (dict.valueForKey("statusText")?.isKindOfClass(NSNull) != true){
                objUser.statusText = dict.valueForKey("statusText") as! String
            }else{
                objUser.statusText = ""
            }
            
            arrUserData.addObject(objUser)
        }
        return arrUserData
    }
 
}
