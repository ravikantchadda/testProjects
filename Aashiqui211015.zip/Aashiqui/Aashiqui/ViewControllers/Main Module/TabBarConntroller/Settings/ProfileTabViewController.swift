//
//  ProfileTabViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 19/10/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class ProfileTabViewController: UIViewController {
    @IBOutlet weak var collVwProfileTabs: UICollectionView!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: UICollectionView Delegate
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return 20
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("cellPhotos", forIndexPath: indexPath)
        // Configure the cell
        
        
        return cell
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath){
        
        
    }
    
    // MARK: UICollectionViewFlowLayout Delegate
    
    func collectionView(collectionView: UICollectionView,
        layout collectionViewLayout: UICollectionViewLayout,
        sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
            //375,414
            if (UIScreen.mainScreen().bounds.size.width == 375){
                return CGSizeMake(118, 118)
            }else if(UIScreen.mainScreen().bounds.size.width == 414){
                return CGSizeMake(131, 131)
            }else{
                return CGSizeMake(100, 100)
            }
            
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
