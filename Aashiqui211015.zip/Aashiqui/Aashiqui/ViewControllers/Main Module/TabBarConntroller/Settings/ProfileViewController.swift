//
//  ProfileViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 15/10/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIActionSheetDelegate {
    @IBOutlet weak var tblFeeds: UITableView!
    @IBOutlet weak var btnPhotos: UIButton!
    @IBOutlet weak var btnPost: UIButton!
    @IBOutlet weak var btnPaired: UIButton!
    @IBOutlet weak var btnLikes: UIButton!
    @IBOutlet weak var btnLikeProfile: UIButton!
    @IBOutlet weak var btnEditProfile: UIButton!
    @IBOutlet weak var imgVwProfilePic: UIImageView!
    @IBOutlet weak var btnRespondRequest: UIButton!
    @IBOutlet weak var vwRightNavButtons: UIView!
    @IBOutlet weak var containerVwTabs: UIView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblLocation: UILabel!
    @IBOutlet weak var imgVwCover: UIImageView!
    var imageEditorController = HFImageEditorViewController()
    var isCover: Bool = false
    var arrFeedData: NSMutableArray! = []
    var pageFeed = 1
    var userID: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationController?.navigationBarHidden = true
        tblFeeds.tableFooterView = UIView(frame: CGRectZero)
        btnPhotos.selected = true
        tblFeeds.hidden = true
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "editProfilePic")
        imgVwProfilePic.addGestureRecognizer(tapGesture)
        
        if userID == "" {
        userID = NSIConstants.userDefaults.valueForKey("userId") as! String
        }
        
        self.navigationController?.navigationBarHidden = true
        pageFeed = 1
        if(self.arrFeedData != nil){
            self.arrFeedData.removeAllObjects()
        }
        let dict:NSDictionary = [
            "userId": userID,
            "visitorId": NSIConstants.userDefaults.valueForKey("userId") as! String
        ]
        print("\(dict)")
        fnGetProfileWebServiceWithPostDic(dict, showLoader: true)
        
        //Paging
        tblFeeds.addInfiniteScrollingWithHandler {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), { () ->  Void in
                self.pageFeed += 1
                let dict:NSDictionary = [
                    "userId": self.userID,
                    "visitorId": NSIConstants.userDefaults.valueForKey("userId") as! String
                ]
                print("\(dict)")
//                self.fnGetFeedsWebServiceWithPostDic(dict, showLoader: false)
            })
        }
        /*
        cropController = DemoImageEditor(nibName: "DemoImageEditor", bundle: nil)
        cropController.setLandscapeAction()
        cropController.checkBounds = true;
        cropController.rotateEnabled = false;
        cropController.doneCallback = {(editedImage: UIImage!, canceled: Bool) in
            if !canceled {
                if self.isCover == true{
                    self.imgVwCover.image = Utility.RBResizeImage(editedImage, targetSize: CGSizeMake(640, 390))
                }
            }
            self.navigationController?.navigationBarHidden = false
            self.navigationController?.popViewControllerAnimated(false)
        }
        */
    }
    
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.navigationBarHidden = true
//        pageFeed = 1
//        if(self.arrFeedData != nil){
//            self.arrFeedData.removeAllObjects()
//        }
//        let dict:NSDictionary = [
//            "userId": NSIConstants.userDefaults.valueForKey("userId") as! String,
//            "visitorId": visitorID
//        ]
//        print("\(dict)")
//        fnGetProfileWebServiceWithPostDic(dict, showLoader: true)
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        self.navigationController?.navigationBarHidden = false
    }
    
    // MARK: - Webservice Call Methods
    //Get Feed API
    func fnGetProfileWebServiceWithPostDic(dict: NSDictionary! , showLoader: Bool) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        //        ObjWebserviceCall.cachePolicy = WebserviceCallCachePolicyRequestFromCacheFirstAndThenFromUrlAndUpdateInCache
        if(showLoader){
            ObjWebserviceCall.isShowLoader = true
        }else{
            ObjWebserviceCall.isShowLoader = false
        }
        
        ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":NSIConstants.userDefaults.valueForKey("AUTHTOKEN") as! String]
        ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceGetProfile)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
            let response = response
            if(response.isResponseFromCache){
                
            }else{
                print("GetFeedResponse \(response.webserviceResponse)")
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    //Profile Model
                    let arrDataProfile = response.webserviceResponse.valueForKey("profileDetail") as! NSDictionary
                    let objProfile = Profile().fillProfileDataInModel(arrDataProfile)
            
                    self.lblName.text = objProfile.firstName + " " + objProfile.lastName
                    self.btnPhotos.setTitle(objProfile.uploadedPhotosCount, forState: UIControlState.Normal)
                    self.btnPhotos.setTitle(objProfile.uploadedPhotosCount, forState: UIControlState.Selected)
                    self.btnPost.setTitle(objProfile.postCount, forState: UIControlState.Normal)
                    self.btnPaired.setTitle(objProfile.friendsCount, forState: UIControlState.Normal)
                    self.btnLikes.setTitle(objProfile.profileGotLikedCount, forState: UIControlState.Normal)
                    
                    //Feed Model
                    let arrDataFeed = response.webserviceResponse.valueForKey("profileDetail")?.valueForKey("posts") as! NSArray
                    Feed().fillDataInModel(arrDataFeed).enumerateObjectsUsingBlock({ object, index, stop in
                        self.arrFeedData.addObject(Feed().fillDataInModel(arrDataFeed).objectAtIndex(index))
                    })
                    print("self.arrFeedData--\(self.arrFeedData)")
                    
                    self.tblFeeds.reloadData()
                    self.tblFeeds.infiniteScrollingView?.stopAnimating()
                    
                }else{
                    self.tblFeeds.infiniteScrollingView?.stopAnimating()
                    if (response.webserviceResponse.valueForKey("status") as! String != "Data not found"){
                        Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                    }
                }
            }
            }) { (error: NSError!) -> Void in
        }
    }
    
    //MARK: - UIButton Action
    @IBAction func btnPressed_Photos(sender: AnyObject) {
        tblFeeds.hidden = true
        containerVwTabs.hidden = false
        btnPhotos.selected = true
        btnPost.selected = false
        btnPaired.selected = false
        btnLikes.selected = false
    }
    @IBAction func btnPressed_Post(sender: AnyObject) {
        tblFeeds.hidden = false
        containerVwTabs.hidden = true
        btnPhotos.selected = false
        btnPost.selected = true
        btnPaired.selected = false
        btnLikes.selected = false
    }
    @IBAction func btnPressed_Paired(sender: AnyObject) {
        tblFeeds.hidden = false
        containerVwTabs.hidden = true
        btnPhotos.selected = false
        btnPost.selected = false
        btnPaired.selected = true
        btnLikes.selected = false
    }
    @IBAction func btnPressed_Likes(sender: AnyObject) {
        tblFeeds.hidden = false
        containerVwTabs.hidden = true
        btnPhotos.selected = false
        btnPost.selected = false
        btnPaired.selected = false
        btnLikes.selected = true
    }
    
    @IBAction func btnPressed_Back(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    @IBAction func btnPressed_AddFriend(sender: AnyObject) {
    }
    @IBAction func btnPressed_Message(sender: AnyObject) {
    }
    @IBAction func btnPressed_More(sender: AnyObject) {
    }
    @IBAction func btnPressed_LikeProfile(sender: AnyObject) {
    }
    @IBAction func btnPressed_EditProfile(sender: AnyObject) {
        isCover = true
        fnChooseImage()
    }
    func editProfilePic(){
        isCover = false
        fnChooseImage()
    }
    
    
    //MARK: - TableView DataSource/Delegate
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (arrFeedData != nil){
            return arrFeedData.count
        }
        return 0
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if(tableView.respondsToSelector(Selector("setSeparatorInset:"))){
            tableView.separatorInset = UIEdgeInsetsZero
        }
        if(tableView.respondsToSelector(Selector("setLayoutMargins:"))){
            if #available(iOS 8.0, *) {
                tableView.layoutMargins = UIEdgeInsetsZero
            } else {
                // Fallback on earlier versions
                tableView.separatorInset = UIEdgeInsetsZero
            }
        }
        if(cell.respondsToSelector(Selector("setLayoutMargins:"))){
            if #available(iOS 8.0, *) {
                cell.layoutMargins = UIEdgeInsetsZero
            } else {
                // Fallback on earlier versions
                cell.separatorInset = UIEdgeInsetsZero
            }
        }
    }
    
    func tableView(tableView: UITableView!, heightForRowAtIndexPath indexPath: NSIndexPath!) -> CGFloat {
        
        return self.getRowHeightFeedCell(indexPath)
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        var strCellIdentifier: NSString
        
        let objFeedCell:Feed = arrFeedData.objectAtIndex(indexPath.row) as! Feed
        
        if(objFeedCell.audioUrl == "" && objFeedCell.photo == "" && objFeedCell.statusText != ""){
            strCellIdentifier = "cellText"
        }
        else if(objFeedCell.audioUrl != "" && objFeedCell.photo == "" && objFeedCell.statusText == ""){
            strCellIdentifier = "cellSound"
        }
        else if(objFeedCell.audioUrl != "" && objFeedCell.photo == "" && objFeedCell.statusText != ""){
            strCellIdentifier = "cellSoundText"
        }
        else if(objFeedCell.audioUrl == "" && objFeedCell.photo != "" && objFeedCell.statusText != ""){
            strCellIdentifier = "cellImgText"
        }
        else if(objFeedCell.audioUrl != "" && objFeedCell.photo != "" && objFeedCell.statusText == ""){
            strCellIdentifier = "cellImgSound"
        }else
        {
            strCellIdentifier = "cellFeedAll"
        }
        let cell = tableView.dequeueReusableCellWithIdentifier(
            strCellIdentifier as String, forIndexPath: indexPath)
        
        //--------------------------UserInfo View--------------------------------
        //UIImage Profile Image
        if let imgVwProfile:AsyncImageView = cell.viewWithTag(1001) as? AsyncImageView {
            imgVwProfile.image = UIImage(named: "placeholder")
            if let variableName: String = objFeedCell.profilePic{
                imgVwProfile.imageURL = NSURL(string: variableName)
            }
        }
        //Label Name
        if let lblName:UILabel = cell.viewWithTag(1002) as? UILabel {
            let strFname: String = objFeedCell.firstName
            let strLname: String = objFeedCell.lastName
            lblName.text = strFname + " " + strLname
        }
        //Label Location
        if let lblLocation:UILabel = cell.viewWithTag(1003) as? UILabel {
            lblLocation.text = objFeedCell.location
            if let imgVwLocation:UIImageView = cell.viewWithTag(4566) as? UIImageView {
                if (lblLocation.text == ""){
                    imgVwLocation.hidden = true
                }else{
                    imgVwLocation.hidden = false
                }
            }
        }
        //Label time
        if let lblTime:UILabel = cell.viewWithTag(1004) as? UILabel {
            let strMin: NSInteger = Int(objFeedCell.minutesAgo)! / 60
            if(strMin == 0){
                if(objFeedCell.minutesAgo == "0"){
                    lblTime.text = "Just now"
                }else{
                    lblTime.text = objFeedCell.minutesAgo + " mins ago"
                }
            }else{
                if (strMin == 1){
                    lblTime.text = String(strMin) + " hour ago"
                }else{
                    lblTime.text = String(strMin) + " hours ago"
                }
            }
        }
        //-----------------------------------------------------------------------
        
        //--------------------------Post Image--------------------------------
        //UIImage Post Image
        if let imgVwPost:AsyncImageView = cell.viewWithTag(1006) as? AsyncImageView {
            imgVwPost.image = UIImage(named: "err")
            if let variableName: String = objFeedCell.photo{
                imgVwPost.crossfadeDuration = 0.0
                imgVwPost.imageURL = NSURL(string: variableName)
            } else {
                // abc is nil
            }
        }
        //-----------------------------------------------------------------------
        
        //        //Sound Wave
        //        if let btnWave:UIButton = cell.viewWithTag(1007) as? UIButton {
        //
        //            btnWave.hidden = false
        //
        //        }
        
        for view in cell.contentView.subviews{
            if(view.tag == 9852 || view.tag == 2589 || view.tag == 4563){
                view.removeFromSuperview()
            }
        }
        
        let lblStatus = UILabel()
        lblStatus.textAlignment = NSTextAlignment.Left
        lblStatus.text = objFeedCell.statusText
        let lblHeight = self.heightForView(lblStatus.text!, width: cell.frame.size.width - 30)
        lblStatus.tag = 9852
        lblStatus.numberOfLines = 0
        lblStatus.font = UIFont(name: "Lato-Regular", size: 14)
        lblStatus.lineBreakMode = NSLineBreakMode.ByWordWrapping
        lblStatus.sizeToFit()
        if(strCellIdentifier == "cellSoundText"){
            lblStatus.frame = CGRectMake(15, 149, cell.frame.size.width - 30, lblHeight + 2)
            cell.contentView.addSubview(lblStatus)
        }else if(strCellIdentifier == "cellText"){
            lblStatus.frame = CGRectMake(15, 79, cell.frame.size.width - 30, lblHeight + 2)
            cell.contentView.addSubview(lblStatus)
        }else if(strCellIdentifier == "cellImgText"){
            lblStatus.frame = CGRectMake(15, 310, cell.frame.size.width - 30, lblHeight + 2)
            cell.contentView.addSubview(lblStatus)
        }else if(strCellIdentifier == "cellFeedAll"){
            lblStatus.frame = CGRectMake(15, 359, cell.frame.size.width - 30, lblHeight + 2)
            cell.contentView.addSubview(lblStatus)
        }
        
        //Tagged Friends
        let arrTagedFriends = objFeedCell.taggedFriendList
        if(arrTagedFriends.count > 0){
            let strTagNames: NSMutableString = "- with "
            if(arrTagedFriends.count > 2){
                
                for var index = 0; index < 2; ++index {
                    strTagNames.appendString(arrTagedFriends.objectAtIndex(index).valueForKey("nickName") as! String)
                    strTagNames.appendString(" ,")
                }
                if (strTagNames.length > 0) {
                    strTagNames.deleteCharactersInRange(NSMakeRange(strTagNames.length-1, 1))
                }
                strTagNames.appendString("and \(arrTagedFriends.count - 2) others")
            }else{
                
                arrTagedFriends.enumerateObjectsUsingBlock({ object, index, stop in
                    let objTaggedFriends:TagFriendList = arrTagedFriends.objectAtIndex(index) as! TagFriendList
                    strTagNames.appendString(objTaggedFriends.nickName)
                    strTagNames.appendString(" ,")
                })
                if (strTagNames.length > 0) {
                    strTagNames.deleteCharactersInRange(NSMakeRange(strTagNames.length-1, 1))
                }
            }
            
            let main_string = strTagNames
            let attributedString = NSMutableAttributedString(string:main_string as String)
            attributedString.addAttribute(NSForegroundColorAttributeName, value: UIColor.blackColor() , range: NSRange(
                location:0,
                length:6))
            attributedString.addAttribute(NSForegroundColorAttributeName, value: UIColor.blueColor() , range: NSRange(
                location:7,
                length:strTagNames.length - 7))
            attributedString.addAttribute(NSFontAttributeName,
                value: UIFont(name: "Lato-Regular", size: 14)!,
                range: NSRange(
                    location: 0,
                    length: strTagNames.length))
            
            let lblTaggedFriend = UILabel()
            lblTaggedFriend.textAlignment = NSTextAlignment.Left
            lblTaggedFriend.attributedText = attributedString
            lblTaggedFriend.frame = CGRectMake(15, lblStatus.frame.origin.y + lblStatus.frame.size.height + 5, cell.frame.size.width - 30, lblHeight)
            lblTaggedFriend.tag = 4563
            lblTaggedFriend.numberOfLines = 1
            lblTaggedFriend.lineBreakMode = NSLineBreakMode.ByWordWrapping
            lblTaggedFriend.sizeToFit()
            cell.contentView.addSubview(lblTaggedFriend)
            
            let btnTagList   = UIButton(type: UIButtonType.Custom) as UIButton
            btnTagList.frame = CGRectMake(15, lblStatus.frame.origin.y + lblStatus.frame.size.height + 5, cell.frame.size.width - 30, 30)
            btnTagList.tag = 2589
            btnTagList.backgroundColor = UIColor.clearColor()
            btnTagList.setTitle("", forState: UIControlState.Normal)
            btnTagList.addTarget(self, action: "buttonActionTagList:", forControlEvents: UIControlEvents.TouchUpInside)
            cell.contentView.addSubview(btnTagList)
        }
        
        //--------------------------Bottom Comment Section--------------------------------
        //Label Views
        if let btnViews:UIButton = cell.viewWithTag(1009) as? UIButton {
            let xString : String = (objFeedCell.viewsCount)!
            btnViews .setTitle(xString + "Views", forState: .Normal)
            
        }
        //Label Comments
        if let btnComments:UIButton = cell.viewWithTag(1010) as? UIButton {
            btnComments .setTitle((objFeedCell.commentsCount)! + " Comments", forState: .Normal)
        }
        //-----------------------------------------------------------------------
        
        return cell
    }
    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
    }
    
    //Calculate UILabel height
    func heightForView(text:String, width:CGFloat) -> CGFloat{
        let label:UILabel = UILabel(frame: CGRectMake(0, 0, width, CGFloat.max))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.ByWordWrapping
        label.font = UIFont(name: "Lato-Regular", size: 14)
        label.text = text
        label.sizeToFit()
        return label.frame.height
    }
    
    //Tag Button Clicked
    func buttonActionTagList(sender:UIButton!)
    {
        Utility.showAlert("", message: NSIConstants.underConstruction, delegate: nil)
    }
    
    //MARK - Get Feed Cell Height
    func getRowHeightFeedCell(indexPath: NSIndexPath) -> CGFloat{
        let objFeedCell:Feed = arrFeedData.objectAtIndex(indexPath.row) as! Feed
        if(objFeedCell.audioUrl == "" && objFeedCell.photo == "" && objFeedCell.statusText != ""){
            let lblHeight = self.heightForView(objFeedCell.statusText, width: tblFeeds.frame.size.width - 30)
            let arrTagedFriends = objFeedCell.taggedFriendList
            if(arrTagedFriends.count > 0){
                return 167 + 20 + lblHeight
            }
            return 167 + lblHeight
        }
        else if(objFeedCell.audioUrl != "" && objFeedCell.photo == "" && objFeedCell.statusText == ""){
            let arrTagedFriends = objFeedCell.taggedFriendList
            if(arrTagedFriends.count > 0){
                return 184 + 20
            }
            return 184
        }
        else if(objFeedCell.audioUrl != "" && objFeedCell.photo == "" && objFeedCell.statusText != ""){
            let lblHeight = self.heightForView(objFeedCell.statusText, width: tblFeeds.frame.size.width - 30)
            let arrTagedFriends = objFeedCell.taggedFriendList
            if(arrTagedFriends.count > 0){
                return 207 + 20 + lblHeight
            }
            return 207 + lblHeight
        }
        else if(objFeedCell.audioUrl == "" && objFeedCell.photo != "" && objFeedCell.statusText != ""){
            let lblHeight = self.heightForView(objFeedCell.statusText, width: tblFeeds.frame.size.width - 30)
            let arrTagedFriends = objFeedCell.taggedFriendList
            if(arrTagedFriends.count > 0){
                return 397 + 20 + lblHeight
            }
            return 397 + lblHeight
            
        }
        else if(objFeedCell.audioUrl != "" && objFeedCell.photo != "" && objFeedCell.statusText == ""){
            return 141
        }else
        {
            let lblHeight = self.heightForView(objFeedCell.statusText, width: tblFeeds.frame.size.width - 30)
            let arrTagedFriends = objFeedCell.taggedFriendList
            if(arrTagedFriends.count > 0){
                return 437 + 20 + lblHeight
            }
            return 437 + lblHeight
        }
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
    }
    
    // MARK: - UIImagePickerControllerDelegate Methods
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        
        if isCover{
            if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
                var cropSize : CGSize
                cropSize = CGSizeMake(320, 190)
                imageEditorController.cropRect = CGRectMake((self.view.frame.size.width-cropSize.width)/2.0, (self.view.frame.size.height-cropSize.height)/2.0, cropSize.width, cropSize.height)
                imageEditorController.checkBounds = true;
                imageEditorController.rotateEnabled = false;
                imageEditorController.minimumScale = 0.2;
                imageEditorController.maximumScale = 10;
                imageEditorController.sourceImage = pickedImage
                imageEditorController.previewImage = pickedImage
                imageEditorController.reset(false)
                imageEditorController.doneCallback = {(editedImage: UIImage!, canceled: Bool) in
                    if !canceled {
                        self.imgVwCover.image = Utility.RBResizeImage(editedImage, targetSize: CGSizeMake(640, 390))
                    }
                    self.dismissViewControllerAnimated(true, completion: nil)
                }
                picker.pushViewController(imageEditorController, animated: true)
            }
        }else{
            if let pickedImage = info[UIImagePickerControllerEditedImage] as? UIImage {
                self.imgVwProfilePic.image = Utility.RBResizeImage(pickedImage, targetSize: CGSizeMake(320, 320))
                dismissViewControllerAnimated(true, completion: nil)
            }else{
                dismissViewControllerAnimated(true, completion: nil)
            }
        }
        
    }
    
    
    func fnChooseImage() {
        if #available(iOS 8.0, *) {
            let objOptionMenu = UIAlertController(title: nil, message: "Choose Option", preferredStyle: .ActionSheet)
            let cameraAction = UIAlertAction(title: "Camera", style: .Default, handler: {
                (alert: UIAlertAction) -> Void in
                self.fnOpenCamera()
            })
            
            let galleryAction = UIAlertAction(title: "Gallery", style: .Default, handler: {
                (alert: UIAlertAction) -> Void in
                self.fnOpenPhotoGallery()
            })
            
            let cancelAction = UIAlertAction(title: "Cancel", style: .Cancel, handler: {
                (alert: UIAlertAction) -> Void in
                
            })
            
            objOptionMenu.addAction(cameraAction)
            objOptionMenu.addAction(galleryAction)
            objOptionMenu.addAction(cancelAction)
            
            self.presentViewController(objOptionMenu, animated: true, completion: nil)
        } else {
            // Fallback on earlier versions
            let objActionSheet = UIActionSheet()
            objActionSheet.title = "Choose Option"
            objActionSheet.addButtonWithTitle("Camera")
            objActionSheet.addButtonWithTitle("Gallery")
            objActionSheet.addButtonWithTitle("Cancel")
            objActionSheet.cancelButtonIndex = 2
            objActionSheet.tag = 2356
            objActionSheet.delegate = self
            objActionSheet.showInView(self.view)
        }
    }
    
    func actionSheet(myActionSheet: UIActionSheet, clickedButtonAtIndex buttonIndex: Int){
        if(myActionSheet.tag == 2356){
            
            if (buttonIndex == 0){
                print("the index is 0")
                self.fnOpenCamera()
            }
            if (buttonIndex == 1){
                print("the index is 1")
                self.fnOpenPhotoGallery()
            }
            if (buttonIndex == 2){
                print("the index is 2")
            }
            
        }
    }
    
    func fnOpenCamera() {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera)
        {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            if isCover{
                imagePicker.allowsEditing = false
            }else{
                imagePicker.allowsEditing = true
            }
            imagePicker.sourceType = UIImagePickerControllerSourceType.Camera;
            self.presentViewController(imagePicker, animated: true, completion: nil)
            
        }else{
            Utility.showAlert("", message: "Camera not available." as String, delegate: nil)
        }
    }
    
    func fnOpenPhotoGallery() {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.PhotoLibrary){
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            if isCover{
                imagePicker.allowsEditing = false
            }else{
                imagePicker.allowsEditing = true
            }
            imagePicker.sourceType = UIImagePickerControllerSourceType.PhotoLibrary;
            self.presentViewController(imagePicker, animated: true, completion: nil)
            
        }else{
            Utility.showAlert("", message: "Gallery not available." as String, delegate: nil)
        }
    }

}
