//
//  SettingsViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 18/09/15.
//  Copyright (c) 2015 Net Solutions. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {
    var dictTableData = [:]
    @IBOutlet weak var tblItems: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationController?.navigationBarHidden = false
        self.navigationItem.title = ""
        self.navigationItem.titleView = Utility.navBarTitleLabel("Settings")
        self.navigationController?.navigationBar.translucent = false
        tblItems.tableFooterView = UIView(frame: CGRectZero)
        
        let arrImages = ["profile","updateProfile","changeUsername","changePassword","notification","terms","chatHistory","logout"]
        let arrName = ["Profile","Update Profile","Change Username","Change Password","Notification","Terms & Policies","Chat History","Logout"]
        dictTableData = ["image": arrImages, "name": arrName]
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK - TableView DataSource/Delegate
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 8
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if(tableView.respondsToSelector(Selector("setSeparatorInset:"))){
            tableView.separatorInset = UIEdgeInsetsZero
        }
        if(tableView.respondsToSelector(Selector("setLayoutMargins:"))){
            if #available(iOS 8.0, *) {
                tableView.layoutMargins = UIEdgeInsetsZero
            } else {
                // Fallback on earlier versions
                tableView.separatorInset = UIEdgeInsetsZero
            }
        }
        if(cell.respondsToSelector(Selector("setLayoutMargins:"))){
            if #available(iOS 8.0, *) {
                cell.layoutMargins = UIEdgeInsetsZero
            } else {
                // Fallback on earlier versions
                cell.separatorInset = UIEdgeInsetsZero
            }
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(
            "cellSettings", forIndexPath: indexPath)
            
        
        if let imgVwLogo = cell.viewWithTag(1001) as? UIImageView {
            let imgName: String = dictTableData["image"]?[indexPath.row] as! String
            imgVwLogo.image = UIImage(named:"\(imgName)")
        }
        if let lblName = cell.viewWithTag(1002) as? UILabel {
            let name: AnyObject? = dictTableData["name"]?[indexPath.row]
            lblName.text = name as? String
        }
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        switch (indexPath.row){
        case 0:
            let objProfileVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("ProfileViewController") as! ProfileViewController
            self.navigationController!.pushViewController(objProfileVC, animated: false)
            break

        case 1:
            break
            
        case 2:
            break
    
        case 3:
            break
            
        case 4:
            let objNotificationSettingVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("NotificationSettingViewController") as! NotificationSettingViewController
            self.navigationController!.pushViewController(objNotificationSettingVC, animated: false)
            break
            
        case 5:
            let objTermsVC = NSIConstants.ObjMainStoryboard.instantiateViewControllerWithIdentifier("TermsViewController") as! TermsViewController
            self.navigationController!.pushViewController(objTermsVC, animated: false)
            break
            
        case 6:
            break
            
        case 7:
            NSIConstants.userDefaults.removeObjectForKey("AUTHTOKEN")
            NSIConstants.userDefaults.removeObjectForKey("userId")
            NSIConstants.userDefaults.synchronize()
            NSIConstants.appDelegate.fnLoginViewController()
            break
    
        default:
            break
            
        }
        
//        if (indexPath.row == 7){
//            NSIConstants.userDefaults.removeObjectForKey("AUTHTOKEN")
//            NSIConstants.userDefaults.removeObjectForKey("userId")
//            NSIConstants.userDefaults.synchronize()
//            let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
//            appDelegate.fnLoginViewController()
//        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
