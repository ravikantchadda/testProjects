//
//  UpdateStatusViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 06/10/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit
import AssetsLibrary
import CoreLocation

class UpdateStatusViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIAlertViewDelegate, CLLocationManagerDelegate {
    
    @IBOutlet weak var collVwPhotoLibrary: UICollectionView!
    @IBOutlet weak var btnCamera: UIButton!
    @IBOutlet weak var btnGallery: UIButton!
    @IBOutlet weak var btnTagFriend: UIButton!
    @IBOutlet weak var imgVwFromCam: UIImageView!
    @IBOutlet weak var tblVwFriendsTag: UITableView!
    @IBOutlet weak var txtVw_Comment: UITextView!
    @IBOutlet weak var lblTaggedFriendName: UILabel!
    @IBOutlet weak var btnRemoveTagFriends: UIButton!
    
    let library = ALAssetsLibrary()
    var count = 0
    var arrImages: NSMutableArray = []
    var arrImagesFullURL: NSMutableArray = []
    var arrImagesSelected: NSMutableArray = []
    var stopped = false
    var indexSelected: NSInteger!
    var arrFriendList: NSArray!
    var arrFriendSelected: NSMutableArray = []
    var strSelectedFriends: NSMutableString = ""
    var strSelectedNames: NSMutableString = ""
    var imageSelected: UIImage!
    let locationManager = CLLocationManager()
    var strLocation: String = ""
    var imageEditorController = HFImageEditorViewController()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.navigationItem.titleView = Utility.navBarTitleLabel("Upload Photo")
        self.navigationItem.hidesBackButton = true
        self.navigationItem.leftBarButtonItem = Utility.navBarLeftButton(UIImage(named: "btnBack")!, viewController: self)
        self.navigationItem.rightBarButtonItem = Utility.navBarRightButton(UIImage(named: "savePost")!, viewController: self)
        tblVwFriendsTag.tableFooterView = UIView(frame: CGRectZero)
        tblVwFriendsTag.allowsMultipleSelection = true
        btnGallery.selected = true
        self.view.bringSubviewToFront(collVwPhotoLibrary)
        btnRemoveTagFriends.hidden = true
        self.collVwPhotoLibrary.allowsMultipleSelection = false
        self.collVwPhotoLibrary.delaysContentTouches = false
        getLatestPhotos(completion: { images in
            //            print(images)
            //Set Images in this block.
            self.collVwPhotoLibrary.reloadData()
        })
        
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        if #available(iOS 9.0, *) {
            locationManager.requestLocation()
            locationManager.requestWhenInUseAuthorization()
        } else {
            // Fallback on earlier versions
            if #available(iOS 8.0, *) {
                locationManager.requestWhenInUseAuthorization()
            }
            // Fallback on earlier versions
            
        }
        locationManager.startUpdatingLocation()
        
//        cropController = DemoImageEditor(nibName: "DemoImageEditor", bundle: nil)
//        cropController.cropRect = CGRectMake((self.view.frame.size.width-320)/2.0, (self.view.frame.size.height-240)/2.0, 320, 250)
//        cropController.checkBounds = true;
//        cropController.rotateEnabled = false;
//        
//        cropController.doneCallback = {(editedImage: UIImage!, canceled: Bool) in
//            if !canceled {
//                self.imageSelected = Utility.RBResizeImage(editedImage, targetSize: CGSizeMake(640, 500))
//                self.imgVwFromCam.image = self.imageSelected
//            }
//            self.navigationController?.popViewControllerAnimated(false)
//        }
    }
    
    // MARK: - CLLocationManagerDelegate
    
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        let isNetwork: Bool = ObjWebserviceCall.checkNetworkConnectivity()
        if (isNetwork){
            // Add below code to get address for touch coordinates.
            if let location = locations.first {
                print("Current location: \(location)")
                let geoCoder = CLGeocoder()
                
                geoCoder.reverseGeocodeLocation(manager.location!, completionHandler: { (placemarks, error) -> Void in
                    let placeArray = placemarks
                    
                    // Place details
                    var placeMark: CLPlacemark!
                    placeMark = placeArray?[0]
                    if (placeMark != nil){
                        // City
                        if let city = placeMark.addressDictionary?["City"] as? NSString
                        {
                            print(city)
                            self.strLocation = city as String
                        }
                        
                        // Location name
                        if let locationName = placeMark.addressDictionary?["Name"] as? NSString
                        {
                            print(locationName)
                            self.strLocation = self.strLocation + " ,\(locationName)"
                        }
                        print("Location---- \(self.strLocation)")
                    }
                    self.locationManager.stopUpdatingLocation()
                })
            } else {
                // ...
            }
        }
    }
    
    func locationManager(manager: CLLocationManager, didFailWithError error: NSError) {
        print("Error finding location: \(error.localizedDescription)")
        Utility.showAlert("", message: "Unable to get your location, please go to Settings and turn on Location Service for this app.", delegate: nil)
    }
    
    // MARK: - Webservice Call Methods
    // SignUp API
    func fnPostImageWebServiceWithPostDic(dict: NSDictionary!) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        //        ObjWebserviceCall.cachePolicy = WebserviceCallCachePolicyRequestFromCacheFirstAndThenFromUrlAndUpdateInCache
        ObjWebserviceCall.isShowLoader = true
        
        if let AuthToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":AuthToken]
            var imgData: NSData? = nil
            ObjWebserviceCall.parametersDict = dict! as [NSObject : AnyObject]
            if((imageSelected) != nil){
//                UIImagePNGRepresentation(imageSelected)
                imgData = UIImageJPEGRepresentation(imageSelected, 1.0)
            }
            ObjWebserviceCall.uploadDataWithImage(imgData, withFileType: "photo", onUrl: NSURL(string: "\(BASE_URL+WebserviceSaveFeed)"), withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("\(response.webserviceResponse)")
                
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    
                    if #available(iOS 8.0, *) {
                        
                        let alert = UIAlertController(title: "", message: NSIConstants.statusUpdateCheck, preferredStyle: .Alert)
                        let action = UIAlertAction(title: "OK", style: .Default) { _ in
                            self.navigationController?.popViewControllerAnimated(true)
                        }
                        alert.addAction(action)
                        self.presentViewController(alert, animated: true, completion: nil)
                        
                    } else {
                        // Fallback on earlier versions
                        Utility.showAlert("", message: NSIConstants.statusUpdateCheck, delegate: self)
                    }
                    
                    
                    
                }else{
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
                
                
                })
                { (error: NSError!) -> Void in
                    let error = error
                    print("\(error)")
            }
        }
        
    }
    
    func alertView(View: UIAlertView, clickedButtonAtIndex buttonIndex: Int){
        
        if (buttonIndex == 0){
            self.navigationController?.popViewControllerAnimated(true)
        }
    }
    
    func getLatestPhotos(completion completionBlock : (NSMutableArray! -> ()))   {
        
        self.library.enumerateGroupsWithTypes(ALAssetsGroupSavedPhotos, usingBlock: { (group, stop) -> Void in
            
            group?.setAssetsFilter(ALAssetsFilter.allPhotos())
            
            group?.enumerateAssetsWithOptions(NSEnumerationOptions.Reverse, usingBlock: {
                (asset : ALAsset!, index, stopEnumeration) -> Void in
                
                if (!self.stopped)
                {
                    if self.count == group.numberOfAssets()
                    {
                        stopEnumeration.memory = ObjCBool(true)
                        stop.memory = ObjCBool(true)
                        completionBlock(self.arrImages)
                        self.stopped = true
                    }
                    else
                    {
                        // For just the thumbnails use the following line.
                        let cgImage = asset.thumbnail().takeUnretainedValue()
                        let imgURL = asset.defaultRepresentation().url()
                        if let image: UIImage = UIImage(CGImage: cgImage ) {
                            self.arrImages.addObject(image)
                            self.arrImagesFullURL.addObject(imgURL)
                            self.arrImagesSelected.addObject("0")
                            self.count += 1
                        }
                        
                    }
                    
                }
            })
            
            },failureBlock : { error in
                print(error)
        })
        
    }
    
    // MARK: - NavigationBar LeftBarButton Method
    func fnLeftBarButton(){
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    // MARK: - NavigationBar RightBarButton Method
    func fnRightBarButton(){
        self.view.endEditing(true)
        if(txtVw_Comment.text == "Add Caption or Status here"){
            Utility.showAlert("", message: "Please Add Caption or Status." as String, delegate: nil)
        }else if((imageSelected) == nil){
            Utility.showAlert("", message: "Please select photo." as String, delegate: nil)
        }
        else{
            
            if let userId = NSIConstants.userDefaults.valueForKey("userId") {
                let dict:NSDictionary = [
                    "userId": userId,
                    "statusText": txtVw_Comment.text,
                    "type": "2",
                    "location": self.strLocation,
                    "taggedFriends": strSelectedFriends,
                    "hashTags": ""
                ]
                print("\(dict)")
                fnPostImageWebServiceWithPostDic(dict)
            }
        }
        
    }
    
    
    // MARK: - UIButton Actions
    @IBAction func btnPressed_Camera(sender: UIButton) {
        btnCamera.selected = true
        btnGallery.selected = false
        btnTagFriend.selected = false
        self.view.bringSubviewToFront(imgVwFromCam)
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera)
        {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.allowsEditing = false
            imagePicker.sourceType = UIImagePickerControllerSourceType.Camera;
            self.presentViewController(imagePicker, animated: true, completion: nil)
            
        }else{
            Utility.showAlert("", message: "Camera not available." as String, delegate: nil)
        }
        
    }
    @IBAction func btnPressed_Gallery(sender: UIButton) {
        btnCamera.selected = false
        btnGallery.selected = true
        btnTagFriend.selected = false
        self.view.bringSubviewToFront(collVwPhotoLibrary)
    }
    @IBAction func btnPressed_TagFriend(sender: UIButton) {
        
        Utility.showAlert("", message: NSIConstants.underConstruction as String, delegate: nil)
        //        btnCamera.selected = false
        //        btnGallery.selected = false
        //        btnTagFriend.selected = true
        //        self.view.bringSubviewToFront(tblVwFriendsTag)
        //
        //
//                if let userId = NSIConstants.userDefaults.valueForKey("userId") {
//                    let dict:NSDictionary = [
//                        "userId": userId,
//                        "page": "1"
//                    ]
//                    print("\(dict)")
//                    fnGetFriendsWebServiceWithPostDic(dict)
//                }
        
    }
    
    
    // MARK: UICollectionView Delegate
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return arrImages.count
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("cell", forIndexPath: indexPath)
        // Configure the cell
        
        if let imgLibrary = cell.contentView.viewWithTag(123) as? UIImageView {
            imgLibrary.image = arrImages.objectAtIndex(indexPath.row) as? UIImage
        }
        
        if (self.arrImagesSelected .objectAtIndex(indexPath.row) as! String == "1"){
            
            let imgVw = UIImageView(frame: CGRectMake(0, 0, cell.frame.size.width, cell.frame.size.height))
            imgVw.image = UIImage(named: "photoSelected")
            imgVw.tag = 6514
            imgVw.contentMode = UIViewContentMode.Center
            if let imgLibrary = cell.contentView.viewWithTag(123) as? UIImageView {
                imgLibrary.alpha = 0.6
            }
            cell.contentView.addSubview(imgVw)
        }else{
            if let imgLibrary = cell.contentView.viewWithTag(123) as? UIImageView {
                imgLibrary.alpha = 1.0
            }
            for view in cell.contentView.subviews{
                if(view.tag == 6514){
                    view.removeFromSuperview()
                }
            }
        }
        
        return cell
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath){
        
        if (indexSelected != nil){
            
            let lastIndexPath:NSIndexPath = NSIndexPath(forRow: indexSelected, inSection: 0)
            self.arrImagesSelected .replaceObjectAtIndex(lastIndexPath.row, withObject: "0")
            
        }
        //        imageSelected = arrImages.objectAtIndex(indexPath.row) as! UIImage
        self.getUIImagefromAsseturl(NSURL(string: "\(arrImagesFullURL.objectAtIndex(indexPath.row))")!)
        let cell : UICollectionViewCell = collectionView.cellForItemAtIndexPath(indexPath)!
        let imgVw = UIImageView(frame: CGRectMake(0, 0, cell.frame.size.width, cell.frame.size.height))
        imgVw.image = UIImage(named: "photoSelected")
        imgVw.tag = 6514
        imgVw.contentMode = UIViewContentMode.Center
        if let imgLibrary = cell.contentView.viewWithTag(123) as? UIImageView {
            imgLibrary.alpha = 0.6
        }
        cell.contentView.addSubview(imgVw)
        indexSelected = indexPath.row
        self.arrImagesSelected .replaceObjectAtIndex(indexPath.row, withObject: "1")
        collVwPhotoLibrary.reloadData()
    }
    
    func getUIImagefromAsseturl (url: NSURL) {
        let asset = ALAssetsLibrary()
        
        asset.assetForURL(url, resultBlock: { asset in
            if let ast = asset {
                let assetRep: ALAssetRepresentation = ast.defaultRepresentation()
                let iref = assetRep.fullResolutionImage().takeUnretainedValue()
//                let image: UIImage = UIImage(CGImage: iref)
                
                
                var imageOrientation: UIImageOrientation = .Up
                let orientValueFromImage = ast.valueForProperty("ALAssetPropertyOrientation") as! NSNumber
                imageOrientation = UIImageOrientation(rawValue: orientValueFromImage.integerValue)!
            
                let image1 = UIImage(CGImage: iref, scale: 1, orientation: imageOrientation)
            
//                self.cropController.sourceImage = image1
//                self.cropController.previewImage = image1
//                self.cropController.reset(false)
//                self.navigationController?.pushViewController(self.cropController, animated: false)
                
                var cropSize : CGSize
                    cropSize = CGSizeMake(320, 250)
                self.imageEditorController.cropRect = CGRectMake((self.view.frame.size.width-cropSize.width)/2.0, (self.view.frame.size.height-cropSize.height)/2.0, cropSize.width, cropSize.height)
                self.imageEditorController.checkBounds = true;
                self.imageEditorController.rotateEnabled = false;
                self.imageEditorController.minimumScale = 0.2;
                self.imageEditorController.maximumScale = 10;
                self.imageEditorController.sourceImage = image1
                self.imageEditorController.previewImage = image1
                self.imageEditorController.reset(false)
                
                self.imageEditorController.doneCallback = {(editedImage: UIImage!, canceled: Bool) in
                    if !canceled {
                        self.imageSelected = Utility.RBResizeImage(editedImage, targetSize: CGSizeMake(640, 500))
                        self.imgVwFromCam.image = self.imageSelected
                    }
                    self.navigationController?.popViewControllerAnimated(false)
                }
                self.navigationController!.pushViewController(self.imageEditorController, animated: false)
            }

            }, failureBlock: { error in
                print("Error: \(error)")
        })
    }
    
    
    // MARK: UICollectionViewFlowLayout Delegate
    
    func collectionView(collectionView: UICollectionView,
        layout collectionViewLayout: UICollectionViewLayout,
        sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
            //375,414
            if (UIScreen.mainScreen().bounds.size.width == 375){
                return CGSizeMake(118, 118)
            }else if(UIScreen.mainScreen().bounds.size.width == 414){
                return CGSizeMake(131, 131)
            }else{
                return CGSizeMake(100, 100)
            }
            
    }
    
    
    // MARK: UITableView Delegate
    
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (self.arrFriendList != nil){
            return self.arrFriendList.count
        }
        return 0
        
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if(tableView.respondsToSelector(Selector("setSeparatorInset:"))){
            tableView.separatorInset = UIEdgeInsetsZero
        }
        if(tableView.respondsToSelector(Selector("setLayoutMargins:"))){
            if #available(iOS 8.0, *) {
                tableView.layoutMargins = UIEdgeInsetsZero
            } else {
                // Fallback on earlier versions
                tableView.separatorInset = UIEdgeInsetsZero
            }
        }
        if(cell.respondsToSelector(Selector("setLayoutMargins:"))){
            if #available(iOS 8.0, *) {
                cell.layoutMargins = UIEdgeInsetsZero
            } else {
                // Fallback on earlier versions
                cell.separatorInset = UIEdgeInsetsZero
            }
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(
            "cellTagFriends", forIndexPath: indexPath)
        
        if let imgVwPic:AsyncImageView = cell.viewWithTag(8001) as? AsyncImageView {
            imgVwPic.image = UIImage(named: "placeholder")
            if let variableName: String = self.arrFriendList.objectAtIndex(indexPath.row).valueForKey("profilePicUrl") as? String{
                imgVwPic.crossfadeDuration = 0.0
                imgVwPic.imageURL = NSURL(string: variableName)
            } else {
                // abc is nil
            }
            //            imgVwPost.hidden = true
        }
        if let lblName = cell.viewWithTag(8002) as? UILabel {
            let strFName = self.arrFriendList.objectAtIndex(indexPath.row).valueForKey("firstName") as! String
            let strLName = self.arrFriendList.objectAtIndex(indexPath.row).valueForKey("lastName") as! String
            let strFullName = strFName + " " + strLName
            lblName.text = strFullName
        }
        
        let btnSelectFriend:UIButton = (cell.viewWithTag(8003) as? UIButton)!
        if(self.arrFriendSelected.objectAtIndex(indexPath.row) as! String == "0"){
            btnSelectFriend.setImage(UIImage(named: "addSong"), forState:UIControlState.Normal)
        }else{
            btnSelectFriend.setImage(UIImage(named: "AddSongSel"), forState:UIControlState.Normal)
        }
        
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
    }
    
    func tableView(tableView: UITableView, didDeselectRowAtIndexPath indexPath: NSIndexPath) {
        
    }
    
    @IBAction func btnPressed_SelectFriend(sender: UIButton) {
        
        let pointInTable: CGPoint = sender.convertPoint(sender.bounds.origin, toView: tblVwFriendsTag)
        let cellIndexPath: NSIndexPath = tblVwFriendsTag.indexPathForRowAtPoint(pointInTable)!
        
        let cell: UITableViewCell = tblVwFriendsTag.cellForRowAtIndexPath(cellIndexPath)!
        let btnSelectFriend:UIButton = (cell.viewWithTag(8003) as? UIButton)!
        if(self.arrFriendSelected.objectAtIndex(cellIndexPath.row) as! String == "0"){
            btnSelectFriend.setImage(UIImage(named: "AddSongSel"), forState:UIControlState.Normal)
            self.arrFriendSelected.replaceObjectAtIndex(cellIndexPath.row, withObject: "1")
        }else{
            btnSelectFriend.setImage(UIImage(named: "addSong"), forState:UIControlState.Normal)
            self.arrFriendSelected.replaceObjectAtIndex(cellIndexPath.row, withObject: "0")
        }
        self.strSelectedFriends = ""
        self.strSelectedNames = ""
        self.arrFriendSelected.enumerateObjectsUsingBlock({ object, index, stop in
            if (self.arrFriendSelected.objectAtIndex(index) as! String == "1"){
                let strID = self.arrFriendList.objectAtIndex(index).valueForKey("userId") as! String
                let strFName = self.arrFriendList.objectAtIndex(index).valueForKey("firstName") as! String
                let strLName = self.arrFriendList.objectAtIndex(index).valueForKey("lastName") as! String
                let strFullName = strFName + " " + strLName
                self.strSelectedFriends.appendString("\(strID),")
                self.strSelectedNames.appendString("   \(strFullName)")
            }
        })
        if (strSelectedFriends.length > 0) {
            strSelectedFriends.deleteCharactersInRange(NSMakeRange(strSelectedFriends.length-1, 1))
        }
        lblTaggedFriendName.text = strSelectedNames as String
        if(strSelectedNames == ""){
            btnRemoveTagFriends.hidden = true
        }else{
            btnRemoveTagFriends.hidden = false
        }
        //        print("names--- \(strSelectedNames)")
        //        print("id--- \(strSelectedFriends)")
    }
    
    @IBAction func btnPressed_RemoveTagFriends(sender: AnyObject) {
        self.strSelectedNames = ""
        lblTaggedFriendName.text = strSelectedNames as String
        btnRemoveTagFriends.hidden = true
    }
    
    
    // MARK: UITextView Delegate
    func textViewDidBeginEditing(textView: UITextView) {
        if textView.text == "Add Caption or Status here" {
            textView.text = ""
            textView.textColor = UIColor.blackColor()
        }
    }
    
    func textViewDidEndEditing(textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = "Add Caption or Status here"
            textView.textColor = UIColor.lightGrayColor()
        }
    }
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        if(text == "\n") {
            textView.resignFirstResponder()
            return false
        }
        let newLength = textView.text.characters.count + text.characters.count - range.length
        return newLength <= 200 // Bool
        //        return true
    }
    
    // MARK: - UIImagePickerControllerDelegate Methods
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            var cropSize : CGSize
            cropSize = CGSizeMake(320, 250)
            imageEditorController.cropRect = CGRectMake((self.view.frame.size.width-cropSize.width)/2.0, (self.view.frame.size.height-cropSize.height)/2.0, cropSize.width, cropSize.height)
            imageEditorController.checkBounds = true;
            imageEditorController.rotateEnabled = false;
            imageEditorController.minimumScale = 0.2;
            imageEditorController.maximumScale = 10;
            imageEditorController.sourceImage = pickedImage
            imageEditorController.previewImage = pickedImage
            imageEditorController.reset(false)
            imageEditorController.doneCallback = {(editedImage: UIImage!, canceled: Bool) in
                if !canceled {
                    self.imageSelected = Utility.RBResizeImage(editedImage, targetSize: CGSizeMake(640, 500))
                    self.imgVwFromCam.image = self.imageSelected
                }
                self.dismissViewControllerAnimated(true, completion: nil)
            }
            
            picker.pushViewController(imageEditorController, animated: true)

        }
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - Webservice Call Methods
    //GetFriends API
    func fnGetFriendsWebServiceWithPostDic(dict: NSDictionary!) {
        let ObjWebserviceCall:WebserviceCall = WebserviceCall()
        //        ObjWebserviceCall.cachePolicy = WebserviceCallCachePolicyRequestFromCacheFirstAndThenFromUrlAndUpdateInCache
        if let authToken = NSIConstants.userDefaults.valueForKey("AUTHTOKEN") {
            // do something here when a highscore exists
            ObjWebserviceCall.isShowLoader = true
            ObjWebserviceCall.headerFieldsDict = ["AUTHTOKEN":authToken]
            ObjWebserviceCall.POST(NSURL(string: "\(BASE_URL+WebserviceGetFriends)"), parameters: dict as [NSObject : AnyObject], withSuccessHandler: { (response: WebserviceResponse!) -> Void in
                let response = response
                print("getFriends--- \(response.webserviceResponse)")
                
                if (response.webserviceResponse.valueForKey("errorCode")?.integerValue == 2000){
                    self.arrFriendList = response.webserviceResponse.valueForKey("friendsList") as! NSArray
                    self.arrFriendList.enumerateObjectsUsingBlock({ object, index, stop in
                        self.arrFriendSelected.addObject("0")
                    })
                    
                    self.tblVwFriendsTag.reloadData()
                }else{
                    
                    Utility.showAlert("", message: response.webserviceResponse.valueForKey("status") as! String, delegate: nil)
                }
                
                }) { (error: NSError!) -> Void in
            }
        }
        else {
            Utility.showAlert("", message: "AuthToken not valid", delegate: nil)
        }
        
    }
    
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    
}
