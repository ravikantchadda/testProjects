//
//  UploadPhotoViewController.swift
//  Aashiqui
//
//  Created by ketan saini on 06/10/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

import UIKit

class UploadPhotoViewController: UIViewController {
    @IBOutlet weak var btnCamera: UIButton!
    @IBOutlet weak var btnGallery: UIButton!
    @IBOutlet weak var btnTagFriend: UIButton!
    @IBOutlet weak var btnMusic: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationItem.titleView = Utility.navBarTitleLabel("Upload Photo")
        self.navigationItem.hidesBackButton = true
        self.navigationItem.leftBarButtonItem = Utility.navBarLeftButton(UIImage(named: "btnBack")!, viewController: self)
    }
    // MARK: - NavigationBar LeftBarButton Method
    func fnLeftBarButton(){
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    // MARK: - UIButton Actions
    @IBAction func btnPressed_Camera(sender: UIButton) {
        btnCamera.selected = true
        btnGallery.selected = false
        btnMusic.selected = false
        btnTagFriend.selected = false
    }
    @IBAction func btnPressed_Gallery(sender: UIButton) {
        btnCamera.selected = false
        btnGallery.selected = true
        btnMusic.selected = false
        btnTagFriend.selected = false
    }
    @IBAction func btnPressed_TagFriend(sender: UIButton) {
        btnCamera.selected = false
        btnGallery.selected = false
        btnMusic.selected = false
        btnTagFriend.selected = true
    }
    @IBAction func btnPressed_Music(sender: UIButton) {
        btnCamera.selected = false
        btnGallery.selected = false
        btnMusic.selected = true
        btnTagFriend.selected = false
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
